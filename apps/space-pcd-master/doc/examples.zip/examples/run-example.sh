#! /bin/sh
pcd -f scripts/examples.pcd -v &
